
<?php
  use DRL\RPACD\includeRPA;
  include 'connect.php';
  try {
    $BatchedPickedDate= $_POST['BatchedPickedDate'];
    $sampletsetid= $_POST['samplesetid'];
    $SampleSetName = $_POST['samplesetname'];
    $ProjectName = $_POST['projectname'];
    $LastResultID= $_POST['LastResultID'];
    $Priority= "Highest";
    $PlantName= $_SESSION['plant'];
    $Status= "Queue";
    $RobotName= '';
    $LastDateProcessed= $_POST['LastDateProcessed']; 
     
    
    
    $stmt = $conn->prepare("{CALL InsertBatchSampleSetQueueLog (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
    $stmt->bindParam(1, $BatchedPickedDate);
    $stmt->bindparam(2, $sampletsetid);
    $stmt->bindparam(3, $SampleSetName);
    $stmt->bindparam(4, $ProjectName);
    $stmt->bindParam(5, $LastResultID);
    $stmt->bindparam(6, $Priority);
    $stmt->bindparam(7, $PlantName);
    $stmt->bindparam(8, $Status);
    $stmt->bindparam(9, $RobotName);
    $stmt->bindParam(10, $LastDateProcessed);
    $stmt->execute();
    $row = array();
    while($result = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $row[] = $result;
    }
    echo json_encode($row);
  } catch (\Exception $e) {
  echo $e;
 }
?>
