
<link rel="stylesheet" href="../assets/css/cdn/normalize.min.css">
<link rel="stylesheet" href="../assets/css/cdn/bootstrap.min.css">
<link rel="stylesheet" href="../assets/css/cdn/datatablecss.min.css">
<link rel="stylesheet" href="../assets/css/cdn/all.css">
<link rel="stylesheet" href="../assets/css/cdn/jquery-ui.css">
<link rel="stylesheet" href="../assets/css/style.css">
<link href="../assets/css/jquery-confirm.css" rel="stylesheet" type="text/css">

