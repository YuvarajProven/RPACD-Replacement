<?php
use DRL\RPACD\includeRPA;
include 'connect.php';

if (isset($_POST['jobId'])) {
    $jobId = $_POST['jobId'];

    try {
        $stmt = $conn->prepare("select Logs.*, Plant.PlantName from Logs LEFT JOIN Plant ON Logs.PlantId = Plant.PlantID where Logs.JobId = ? Order BY Logs.Id DESC");
        $stmt->bindParam(1, $jobId);
        $stmt->execute();

        $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($logs);
    } catch (PDOException $e) {
        echo "Error fetching logs: " . $e->getMessage();
    }
} else {
    echo "Invalid request";
}
?>
 