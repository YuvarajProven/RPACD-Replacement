<!--  All the script files  -->
<script src="../assets/js/scripts/jquery-2.2.4.min.js"></script>
<script src="../assets/allcdnfiles/bootstrapjs.js"></script>
<script src="../assets/js/scripts/jquery.dataTables.min.js"></script>
<script src="../assets/js/scripts/jszip.min.js"></script>
<script src="../assets/js/scripts/vfs_fonts.js"></script>
<script src="../assets/js/scripts/pdfmake.min.js"></script>
<script src="../assets/js/scripts/dataTables.buttons.min.js"></script>
<script src="../assets/js/scripts/buttons.html5.min.js"></script>
<script src="../assets/js/scripts/sweetalert.min.js"></script>
<script src="../assets/js/scripts/jquery-ui.js"></script>
<script src="../assets/js/scripts/weekdateslink.min.js"></script>
<script src="../assets/js/chartjs.js"></script>
<script src="../assets/js/common.js"></script>
<script src="../assets/js/jquery-confirm.js" charset="utf-8"></script>

