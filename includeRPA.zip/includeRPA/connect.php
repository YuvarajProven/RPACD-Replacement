<?php
  error_reporting(0);

  if(session_status() == PHP_SESSION_NONE){
      session_start();
  }
  date_default_timezone_set('Asia/Kolkata');
try
  {
    $plant = $_SESSION['plant'];
    if ($plant != 'FTO3') {
      $conn = new PDO("sqlsrv:server=INCRPVLIMSDBVAL\RPAQTYDB;Database=RPA_Quality_FTO2_RT_Dev","rpadev","Rp@dev123");
      $conn -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
else if ($plant != 'CTO6') {
      $conn = new PDO("sqlsrv:server=INCRPVLIMSDBVAL\RPAQTYDB;Database=RPA_Quality_FTO2_RT_Dev","rpadev","Rp@dev123");
      $conn -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    else
	{
		$conn = new PDO("sqlsrv:server=INCRPVLIMSDBVAL\RPAQTYDB;Database=RPA_Quality_FTO2_RT_Dev","rpadev","Rp@dev123");
      		$conn -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
  }
  catch(Exception $e)
  {
      die(print_r( $e->getMessage() ) );
  }
?>
